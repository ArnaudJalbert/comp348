"""
Arnaud Jalbert, 40134632
"""

1. Make sure to start the server BEFORE doing any commands else the client will crash

2. Make sure to include the menu.txt in the folder, that's how the menu is printed.
   The program will crash without it it is included in my submission so normally 
   nothing needs to be done.

3. Program assumes the DB is file "data.txt" and that it's in the folder, also need to 
   make sure the DB used for testing is named like that else it will crash.

Thank you!